package uz.pdp.online;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "uz.pdp.online")
public class StoreAutoConfig {
}
