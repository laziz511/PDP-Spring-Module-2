package uz.pdp.online;


import org.springframework.stereotype.Component;

@Component
public class Item {
}
