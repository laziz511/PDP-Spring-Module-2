package uz.pdp.online.dto;

public record UserRegisterDTO(String username, String password) {
}
