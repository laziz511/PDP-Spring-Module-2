package uz.pdp.online.repository;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Repository;
import uz.pdp.online.mapper.AuthUserRowMapper;
import uz.pdp.online.model.AuthUser;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static uz.pdp.online.repository.ColumnConstants.*;

@Repository
@RequiredArgsConstructor
public class AuthUserRepository {

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private static final String SAVE_SQL = """
            INSERT INTO auth_user (username, password, blocked)
            VALUES (:username, :password, :blocked)
            """;

    private static final String FIND_ALL_SQL = "SELECT * FROM auth_user";

    private static final String FIND_BY_ID_SQL = "SELECT * FROM auth_user WHERE id = :id";

    private static final String FIND_BY_USERNAME_SQL = """
            SELECT * FROM auth_user WHERE username = :username
            """;

    private static final String UPDATE_SQL = """
            UPDATE auth_user SET username = :username, password = :password, blocked = :blocked WHERE id = :id
            """;

    public void save(AuthUser user) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put(USERNAME, user.getUsername());
        parameters.put(PASSWORD, user.getPassword());
        parameters.put(BLOCKED, user.isBlocked());

        namedParameterJdbcTemplate.update(SAVE_SQL, parameters);
    }

    public List<AuthUser> findAll() {
        return namedParameterJdbcTemplate.query(FIND_ALL_SQL, new AuthUserRowMapper());
    }

    public Optional<AuthUser> findById(Long id) {
        MapSqlParameterSource paramSource = new MapSqlParameterSource().addValue(ID, id);
        try {
            AuthUser user = namedParameterJdbcTemplate.queryForObject(FIND_BY_ID_SQL, paramSource, new AuthUserRowMapper());
            return Optional.ofNullable(user);
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    public Optional<AuthUser> findByUsername(@NonNull String username) {
        MapSqlParameterSource paramSource = new MapSqlParameterSource().addValue(USERNAME, username);
        try {
            AuthUser user = namedParameterJdbcTemplate.queryForObject(FIND_BY_USERNAME_SQL, paramSource, new AuthUserRowMapper());
            return Optional.ofNullable(user);
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    public void update(AuthUser user) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put(ID, user.getId());
        parameters.put(USERNAME, user.getUsername());
        parameters.put(PASSWORD, user.getPassword());
        parameters.put(BLOCKED, user.isBlocked());

        namedParameterJdbcTemplate.update(UPDATE_SQL, parameters);
    }
}
